#!/bin/bash
cd /content/idr; s=$(date +%s)
python3 idr_eval.py "$1" "$2" q17 http://127.0.0.1:8000/v1 deepseek-v4-flash http://127.0.0.1:8090/v1 "$3" > "$3.log" 2>&1
echo "exit=$? seconds=$(( $(date +%s) - s ))" > "$3.done"
